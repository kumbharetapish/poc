import React from "react";

export default function Page404() {
  return (
    <div>
      <h1>Page Not Fount </h1>
      <h4>404 error</h4>
    </div>
  );
}
