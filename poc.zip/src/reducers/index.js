import { combineReducers } from "redux";
import FormOperation from "./FormOperation";

const rootReducer = combineReducers({
  FormOperation,
});

export default rootReducer;
